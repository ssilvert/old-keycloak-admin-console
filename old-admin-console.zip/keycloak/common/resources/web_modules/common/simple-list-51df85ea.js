var a=void 0;export{a as default};
//# sourceMappingURL=simple-list-51df85ea.js.map
