var a=void 0;export{a as default};
//# sourceMappingURL=truncate-1090be09.js.map
