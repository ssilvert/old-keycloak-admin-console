var a=void 0;export{a as default};
//# sourceMappingURL=badge-1581c7f3.js.map
