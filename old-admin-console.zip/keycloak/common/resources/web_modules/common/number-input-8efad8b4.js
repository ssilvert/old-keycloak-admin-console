var a=void 0;export{a as default};
//# sourceMappingURL=number-input-8efad8b4.js.map
