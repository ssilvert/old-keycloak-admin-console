var a=void 0;export{a as default};
//# sourceMappingURL=slider-4c35ac06.js.map
