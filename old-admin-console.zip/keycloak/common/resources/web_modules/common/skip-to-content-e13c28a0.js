var a=void 0;export{a as default};
//# sourceMappingURL=skip-to-content-e13c28a0.js.map
