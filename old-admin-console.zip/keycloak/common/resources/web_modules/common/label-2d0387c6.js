var a=void 0;export{a as default};
//# sourceMappingURL=label-2d0387c6.js.map
