var a=void 0;export{a as default};
//# sourceMappingURL=menu-toggle-4c45fb2d.js.map
