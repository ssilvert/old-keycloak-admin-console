var a=void 0;export{a as default};
//# sourceMappingURL=label-group-06262c8d.js.map
