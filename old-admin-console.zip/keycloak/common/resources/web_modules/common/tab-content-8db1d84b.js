var a=void 0;export{a as default};
//# sourceMappingURL=tab-content-8db1d84b.js.map
