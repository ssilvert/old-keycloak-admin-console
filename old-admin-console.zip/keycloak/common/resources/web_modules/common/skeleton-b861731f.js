var a=void 0;export{a as default};
//# sourceMappingURL=skeleton-b861731f.js.map
