var a=void 0;export{a as default};
//# sourceMappingURL=expandable-section-97c66488.js.map
