var a=void 0;export{a as default};
//# sourceMappingURL=description-list-add07718.js.map
