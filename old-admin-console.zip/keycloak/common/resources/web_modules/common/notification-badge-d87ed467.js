var a=void 0;export{a as default};
//# sourceMappingURL=notification-badge-d87ed467.js.map
