var a=void 0;export{a as default};
//# sourceMappingURL=jump-links-4644d717.js.map
