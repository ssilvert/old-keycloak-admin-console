var a=void 0;export{a as default};
//# sourceMappingURL=clipboard-copy-33ec02a6.js.map
