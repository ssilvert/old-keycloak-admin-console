var a=void 0;export{a as default};
//# sourceMappingURL=background-image-52964ac4.js.map
