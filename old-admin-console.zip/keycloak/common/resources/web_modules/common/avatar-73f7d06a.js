var a=void 0;export{a as default};
//# sourceMappingURL=avatar-73f7d06a.js.map
