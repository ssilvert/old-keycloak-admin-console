var a=void 0;export{a as default};
//# sourceMappingURL=accordion-d2be3ec4.js.map
