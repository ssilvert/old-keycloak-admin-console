var a=void 0;export{a as default};
//# sourceMappingURL=card-f72c9492.js.map
