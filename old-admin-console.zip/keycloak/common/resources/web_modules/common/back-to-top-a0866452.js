var a=void 0;export{a as default};
//# sourceMappingURL=back-to-top-a0866452.js.map
