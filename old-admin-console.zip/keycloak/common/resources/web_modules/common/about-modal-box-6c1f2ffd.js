var a=void 0;export{a as default};
//# sourceMappingURL=about-modal-box-6c1f2ffd.js.map
